<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class KelurahanSeeder extends Seeder
{
    public function run()
    {
        $kelurahans = [
            ['nama' => 'Kelurahan A', 'kecamatan_id' => 1], // Assuming 'Klojen' has id 1
            ['nama' => 'Kelurahan B', 'kecamatan_id' => 2]  // Assuming 'Blimbing' has id 2
        ];

        DB::table('kelurahans')->insert($kelurahans);
    }
}
